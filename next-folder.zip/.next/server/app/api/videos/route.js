var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/videos/route.js")
R.c("server/chunks/[root-of-the-server]__ca2eef05._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_videos_route_actions_d409b075.js")
R.m(2525)
module.exports=R.m(2525).exports
