(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_f73594eb._.css",
  "static/chunks/node_modules_next_dist_60d9f176._.js",
  "static/chunks/components_9dbe256c._.js"
],
    source: "dynamic"
});
