(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_db0f815f._.css",
  "static/chunks/components_ContactForm_9c281d95._.js"
],
    source: "dynamic"
});
