module.exports = [
"[project]/.next-internal/server/app/checkout/[productId]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_checkout_%5BproductId%5D_page_actions_10685e25.js.map