module.exports = [
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[project]/app/layout.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/layout.tsx [app-rsc] (ecmascript)"));
}),
"[project]/app/videos/videos.module.css [app-rsc] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "description": "videos-module__KSuI1q__description",
  "socialIcons": "videos-module__KSuI1q__socialIcons",
  "socialLink": "videos-module__KSuI1q__socialLink",
  "socialLinks": "videos-module__KSuI1q__socialLinks",
  "socialTitle": "videos-module__KSuI1q__socialTitle",
  "title": "videos-module__KSuI1q__title",
  "video": "videos-module__KSuI1q__video",
  "videoCard": "videos-module__KSuI1q__videoCard",
  "videoDescription": "videos-module__KSuI1q__videoDescription",
  "videoFrame": "videos-module__KSuI1q__videoFrame",
  "videoInfo": "videos-module__KSuI1q__videoInfo",
  "videoTitle": "videos-module__KSuI1q__videoTitle",
  "videosContainer": "videos-module__KSuI1q__videosContainer",
  "videosGrid": "videos-module__KSuI1q__videosGrid",
  "videosSection": "videos-module__KSuI1q__videosSection",
});
}),
"[project]/app/videos/page.tsx [app-rsc] (ecmascript)", ((__turbopack_context__, module, exports) => {

const e = new Error("Could not parse module '[project]/app/videos/page.tsx'\n\nawait isn't allowed in non-async function");
e.code = 'MODULE_UNPARSABLE';
throw e;
}),
"[project]/app/videos/page.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/videos/page.tsx [app-rsc] (ecmascript)"));
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__230ef29c._.js.map