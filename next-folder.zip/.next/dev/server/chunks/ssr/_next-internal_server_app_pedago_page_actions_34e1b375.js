module.exports = [
"[project]/.next-internal/server/app/pedago/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_pedago_page_actions_34e1b375.js.map