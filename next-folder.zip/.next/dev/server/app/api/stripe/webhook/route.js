var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/stripe/webhook/route.js")
R.c("server/chunks/node_modules_next_4a923908._.js")
R.c("server/chunks/node_modules_stripe_esm_28143d30._.js")
R.c("server/chunks/node_modules_svix_dist_7132ddd4._.js")
R.c("server/chunks/node_modules_b6aa6438._.js")
R.c("server/chunks/[root-of-the-server]__862016d2._.js")
R.c("server/chunks/_next-internal_server_app_api_stripe_webhook_route_actions_4b229d15.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/stripe/webhook/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/stripe/webhook/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
