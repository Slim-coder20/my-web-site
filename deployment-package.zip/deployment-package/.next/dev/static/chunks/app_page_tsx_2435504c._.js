(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_page_module_2b22cb52.css",
  "static/chunks/app_74532337._.js"
],
    source: "dynamic"
});
