(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_about_about_module_e4dc6ca0.css",
  "static/chunks/node_modules_next_dist_60d9f176._.js"
],
    source: "dynamic"
});
