(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_ae7befaa._.css",
  "static/chunks/node_modules_next_a62874fb._.js",
  "static/chunks/components_ConcertCard_d01de2a9._.js"
],
    source: "dynamic"
});
