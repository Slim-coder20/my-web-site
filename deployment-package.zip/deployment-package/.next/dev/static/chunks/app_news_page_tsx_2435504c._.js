(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_news_news_module_c0d031f3.css",
  "static/chunks/node_modules_next_dist_60d9f176._.js"
],
    source: "dynamic"
});
