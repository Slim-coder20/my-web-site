var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/checkout/route.js")
R.c("server/chunks/node_modules_29456b4c._.js")
R.c("server/chunks/[root-of-the-server]__6c22cf0e._.js")
R.c("server/chunks/_next-internal_server_app_api_checkout_route_actions_414bfd84.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/checkout/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/checkout/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
